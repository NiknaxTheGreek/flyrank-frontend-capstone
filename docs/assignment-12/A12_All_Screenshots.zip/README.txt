Assignment 12 - Screenshots from this chat and its saved audit evidence

23 original screenshots. No videos were attached or recorded in this A12 chat.

Folders:
- live-before: deployed Lighthouse baseline
- live-after: final deployed Lighthouse, WAVE, phone and catalogue keyboard evidence
- live-first-pass / live-second-pass: intermediate Home audits
- local-before / local-after: original local Lighthouse and WAVE comparisons
- keyboard: streaming, Stop, recovery and mobile screenshots

Local Home/Account audits used handled unconfigured states; live-after contains the deployed configured app.

Source: NiknaxTheGreek/flyrank-frontend-capstone, fe12-performance-accessibility, docs/assignment-12/evidence.
Original image bytes and filenames have been preserved.

Inventory:
A12_Screenshots/keyboard/phone-conversation.jpg
A12_Screenshots/keyboard/recovered-tool.jpg
A12_Screenshots/keyboard/skip-link.jpg
A12_Screenshots/keyboard/stop-focused.jpg
A12_Screenshots/live-after/catalog-fixture/search-result-focused.jpg
A12_Screenshots/live-after/chat-mobile.jpg
A12_Screenshots/live-after/home-mobile.jpg
A12_Screenshots/live-after/live-chat-phone.jpg
A12_Screenshots/live-after/live-home-phone.jpg
A12_Screenshots/live-after/wave/account.jpg
A12_Screenshots/live-after/wave/chat.jpg
A12_Screenshots/live-after/wave/home.jpg
A12_Screenshots/live-after/wave/motion.jpg
A12_Screenshots/live-before/chat-mobile.jpg
A12_Screenshots/live-before/home-mobile.jpg
A12_Screenshots/live-first-pass/home-mobile.jpg
A12_Screenshots/live-second-pass/home-mobile.jpg
A12_Screenshots/local-after/chat-mobile.jpg
A12_Screenshots/local-after/home-mobile.jpg
A12_Screenshots/local-after/wave/motion.jpg
A12_Screenshots/local-before/chat-mobile.jpg
A12_Screenshots/local-before/home-mobile.jpg
A12_Screenshots/local-before/wave/motion.jpg
