A9 and A10 — Saved Assignment Files

A9: three screenshots and the assignment/submission notes.
A10: one CI report screenshot, assignment/submission notes, and verification logs.

These are the original files saved in the assignment branches, copied without editing.
No video files are present in the A9 or A10 evidence folders.

CONTENTS
A9/README.md (5233 bytes)
A9/evidence/desktop-error.jpg (150643 bytes)
A9/evidence/desktop-idle.jpg (149619 bytes)
A9/evidence/reduced-motion-error.jpg (150332 bytes)
A9/submission.md (1903 bytes)
A10/README.md (7496 bytes)
A10/evidence/ci-run.txt (45790 bytes)
A10/evidence/ci-suite.png (102830 bytes)
A10/evidence/ci-verified-results.json (617 bytes)
A10/evidence/renderer-before-fix.txt (7242 bytes)
A10/evidence/vitest-after-fix.txt (1800 bytes)
A10/submission.md (2155 bytes)

SOURCE REVISIONS
A9: fe09-button-lifecycle at 8bec92bfbf7ce9a06da26c606a095bbb8b5b67c0
A10: fe10-tests-and-ci at fdccb21526163094e5881192403f782c2057d606
